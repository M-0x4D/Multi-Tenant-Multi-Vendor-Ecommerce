<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class ProductCart extends Model 
{

    protected $table = 'product_cart';
    public $timestamps = true;
    protected $fillable = array('cart_id', 'product_id');

}