<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model 
{

    protected $table = 'cart';
    public $timestamps = true;

    public function products()
    {
        return $this->belongsToMany('App\models\Product');
    }

}