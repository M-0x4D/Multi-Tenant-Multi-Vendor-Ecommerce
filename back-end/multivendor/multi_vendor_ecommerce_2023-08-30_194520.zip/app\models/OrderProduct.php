<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class OrderProduct extends Model 
{

    protected $table = 'order_products';
    public $timestamps = true;
    protected $fillable = array('order_id', 'product_id', 'price_at_this_time');

}