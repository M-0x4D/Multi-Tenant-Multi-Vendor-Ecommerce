<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Offer extends Model 
{

    protected $table = 'offers';
    public $timestamps = true;
    protected $fillable = array('category_id', 'product_id', 'percentage', 'image', 'from_date', 'to_date');

    public function products()
    {
        return $this->hasMany('App\models\Product');
    }

    public function categories()
    {
        return $this->hasMany('App\models\Category');
    }

}