<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Eloquent\Model;

class CreateForeignKeys extends Migration {

	public function up()
	{
		Schema::table('products', function(Blueprint $table) {
			$table->foreign('category_id')->references('id')->on('categories')
						->onDelete('restrict')
						->onUpdate('restrict');
		});
		Schema::table('images', function(Blueprint $table) {
			$table->foreign('product_id')->references('id')->on('products')
						->onDelete('restrict')
						->onUpdate('restrict');
		});
		Schema::table('offers', function(Blueprint $table) {
			$table->foreign('category_id')->references('id')->on('categories')
						->onDelete('restrict')
						->onUpdate('restrict');
		});
		Schema::table('offers', function(Blueprint $table) {
			$table->foreign('product_id')->references('id')->on('products')
						->onDelete('restrict')
						->onUpdate('restrict');
		});
		Schema::table('shipping_governrate', function(Blueprint $table) {
			$table->foreign('shipping_method_id')->references('id')->on('shipping_methods')
						->onDelete('restrict')
						->onUpdate('restrict');
		});
		Schema::table('shipping_governrate', function(Blueprint $table) {
			$table->foreign('governrate_id')->references('id')->on('governrates')
						->onDelete('restrict')
						->onUpdate('restrict');
		});
		Schema::table('shipping_addresses', function(Blueprint $table) {
			$table->foreign('rememberToken')->references('id')->on('governrates')
						->onDelete('restrict')
						->onUpdate('restrict');
		});
		Schema::table('shipping_addresses', function(Blueprint $table) {
			$table->foreign('governrate_id')->references('id')->on('governrates')
						->onDelete('restrict')
						->onUpdate('restrict');
		});
	}

	public function down()
	{
		Schema::table('products', function(Blueprint $table) {
			$table->dropForeign('products_category_id_foreign');
		});
		Schema::table('images', function(Blueprint $table) {
			$table->dropForeign('images_product_id_foreign');
		});
		Schema::table('offers', function(Blueprint $table) {
			$table->dropForeign('offers_category_id_foreign');
		});
		Schema::table('offers', function(Blueprint $table) {
			$table->dropForeign('offers_product_id_foreign');
		});
		Schema::table('shipping_governrate', function(Blueprint $table) {
			$table->dropForeign('shipping_governrate_shipping_method_id_foreign');
		});
		Schema::table('shipping_governrate', function(Blueprint $table) {
			$table->dropForeign('shipping_governrate_governrate_id_foreign');
		});
		Schema::table('shipping_addresses', function(Blueprint $table) {
			$table->dropForeign('shipping_addresses_rememberToken_foreign');
		});
		Schema::table('shipping_addresses', function(Blueprint $table) {
			$table->dropForeign('shipping_addresses_governrate_id_foreign');
		});
	}
}