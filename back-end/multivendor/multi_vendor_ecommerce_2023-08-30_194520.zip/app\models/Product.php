<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model 
{

    protected $table = 'products';
    public $timestamps = true;
    protected $fillable = array('category_id', 'name', 'price', 'description');

    public function orders()
    {
        return $this->belongsToMany('App\models\Order');
    }

    public function category()
    {
        return $this->belongsTo('App\models\Category');
    }

    public function sizes()
    {
        return $this->belongsToMany('App\models\Size');
    }

    public function carts()
    {
        return $this->belongsToMany('App\models\Cart');
    }

    public function offer()
    {
        return $this->belongsTo('App\models\Offer');
    }

    public function images()
    {
        return $this->hasMany('App\models\Image');
    }

}