<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateReviewsTable extends Migration {

	public function up()
	{
		Schema::create('reviews', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->decimal('rate', 2,1);
			$table->text('comment');
			$table->integer('reviewable_id');
			$table->string('reviewable_type', 100);
		});
	}

	public function down()
	{
		Schema::drop('reviews');
	}
}