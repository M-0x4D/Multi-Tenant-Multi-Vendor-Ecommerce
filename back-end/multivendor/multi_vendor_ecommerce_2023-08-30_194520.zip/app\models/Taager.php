<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Taager extends Model 
{

    protected $table = 'taager';
    public $timestamps = true;
    protected $fillable = array('name', 'email', 'password', 'phone_number', 'otp', 'otp_valid', 'email_verified_at', 'phone_verified_at', 'status', 'paid');

}