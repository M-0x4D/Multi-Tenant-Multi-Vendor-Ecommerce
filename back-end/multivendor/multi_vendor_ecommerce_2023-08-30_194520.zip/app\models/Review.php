<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Review extends Model 
{

    protected $table = 'reviews';
    public $timestamps = true;
    protected $fillable = array('rate', 'comment', 'reviewable_id', 'reviewable_type');

}