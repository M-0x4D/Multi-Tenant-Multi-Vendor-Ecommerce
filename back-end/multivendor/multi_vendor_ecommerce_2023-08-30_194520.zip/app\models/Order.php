<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model 
{

    protected $table = 'orders';
    public $timestamps = true;
    protected $fillable = array('order_number', 'order_date_time', 'total_price');

    public function products()
    {
        return $this->belongsToMany('App\models\Product');
    }

}