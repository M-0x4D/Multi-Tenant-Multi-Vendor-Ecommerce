<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTaagerTable extends Migration {

	public function up()
	{
		Schema::create('taager', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->string('name', 100);
			$table->string('email', 100);
			$table->string('password', 100);
			$table->integer('phone_number');
			$table->string('otp', 10);
			$table->boolean('otp_valid');
			$table->date('email_verified_at');
			$table->date('phone_verified_at');
			$table->enum('status', array('active', 'pending'));
			$table->boolean('paid');
		});
	}

	public function down()
	{
		Schema::drop('taager');
	}
}