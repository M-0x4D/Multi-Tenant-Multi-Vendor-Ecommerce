<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateOrdersTable extends Migration {

	public function up()
	{
		Schema::create('orders', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->integer('order_number');
			$table->date('order_date_time');
			$table->decimal('total_price', 8,2);
		});
	}

	public function down()
	{
		Schema::drop('orders');
	}
}